# `mono.dark`

![mono_dark](mono_dark.jpg)

# `mono.light`

![mono_light](mono_light.jpg)

# `hershey.light`

![hershey_light](hershey_light.jpg)

# `hershey.dark`

![hershey_dark](hershey_dark.jpg)

# `fancy.light`

![fancy_light](fancy_light.jpg)

# `fancy.dark`

![fancy_dark](fancy_dark.jpg)

# `Latex`

![Latex](latex.jpg)

# `Plain`

![Plain](plain.jpg)

