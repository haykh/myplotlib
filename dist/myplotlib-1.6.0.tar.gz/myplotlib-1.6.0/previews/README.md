# `classic.light`

![classic_light](classic_light.png)

# `fancy.light`

![fancy_light](fancy_light.png)

# `classic.dark`

![classic_dark](classic_dark.png)

# `mono.light`

![mono_light](mono_light.png)

# `fancy.dark`

![fancy_dark](fancy_dark.png)

# `mono.dark`

![mono_dark](mono_dark.png)

# `Latex`

![Latex](latex.png)

# `Plain`

![Plain](plain.png)

